<?php

  session_start();                           //se indica que estamos iniciando una sesion
  require("conexion.php");
  
    if(isset($_SESSION["id_usuario"])){                   //Comprobara si ya hay una sesion iniciada   
    header("Location: welcome.php");                                    //si es asi nos redireccionara a la pagina principal
   }
  if(!empty($_POST)){                                             //Evaluar si estamos enviando el formulario Evalua que la variable POST no este vacia
//    $nombre=mysqli_real_escape_string($mysqli,$_POST['nombre']);        //Filtra los String que recibe del POST
    $id_usuario=mysqli_real_escape_string($mysqli,$_POST['nombre']);
    $password=mysqli_real_escape_string($mysqli,$_POST['password']);    
        $estado='';
    $error='';    
    $sha1_pass=sha1($password);//cifrar los datos en php

    $sql="SELECT estado FROM usuarios WHERE Usuario_Log='$id_usuario'";
    $result=$mysqli->query($sql);
    $rows= $result-> num_rows;
    if($rows > 0){
      while($row=$result->fetch_assoc()) {
        $row['estado'];
        $estado = $row['estado'];
      }
        }else{
       $error = "Error no encontro un estado de actividad en el registro del usuario.";
    }

    if($estado == 'activo'){
    //$sql="SELECT id_usuario,id_priv FROM usuarios WHERE nombre='$nombre' AND contrasenia ='$sha1_pass'";     //iniciar sesion con su NOMBRE y CONTRASEÑA
    $sql="SELECT id_usuario,Usuario_Log,Id_Priv,Tipo_Usuario FROM usuarios WHERE Usuario_Log='$id_usuario' AND contrasena ='$sha1_pass'"; //iniciar sesion con su ID y su CONTRASEÑA
    $result=$mysqli->query($sql);
    $rows= $result-> num_rows;               //Comprobar que la consulta arroja un resultado
      if($rows > 0){
        $row= $result->fetch_assoc();
        $_SESSION['id_usuario'] = $row['id_usuario'];                //row trae todos los datos de la consulta (solo 1 por la sesion)
        $_SESSION['Usuario_Log'] = $row['Usuario_Log'];//envia la variable idusuario a welcome
        $_SESSION['Id_Priv']= $row['Id_Priv']; 
         $_SESSION['Tipo_Usuario']= $row['Tipo_Usuario'];      //envia la variable tipousuarios   2
        header("location: welcome.php");       //redireciona si el usuario es correcto con header a welcome.php
                               //utf8_decode($row['nombre']); 
      }else{
        $error = "El ID o contrasenia son incorrectos, por favor intenta de nuevo.";
      }
      }else{
      $error = "No se encuntra dado de alta en sistema.";
    }
  }
?>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <!--CSS de Bootstrap 4.2.1-->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <!--Font Awesome-->
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,500&display=swap" rel="stylesheet">
    <!-- owner -->
       <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
        integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <!--Google Fonts-->

    <link rel="stylesheet" href="assets/css/style.css">

 
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top color-fondo " style="  background-color:#2b130c;">
             <section class="container">
                <a class="navbar-brand" href="#">
                    <img  class="mb-2" src="imagenes/logo_c.png" width="200" height="70" class="img-fluid" alt="logo-black">
                </a>

            

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto ">
                       

    






                </div>
            </section>
        </nav>
    </header>


  <div align="center">
      <div id="loginbox" style="text-align: center; align-content: center; " class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2" >
        <div class="panel panel-info"  style="margin-top:175px; align-content: center;">
          <div class="panel-heading" style="margin-top:175px; ">
            <div class="panel-title" style=" align-content: center;">Iniciar Sesi&oacute;n</div>
          </div>

          
            <form id="loginform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" autocomplete="off">
              <div style="margin-bottom: 25px" class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                <input id="usuario" type="text" class="form-control" name="nombre" value="" placeholder="ID del Usuario" required> 
              </div>
              
              <div style="margin-bottom: 25px" class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                <input id="password" type="password" class="form-control" name="password" placeholder="Contraseña" required>
              </div>
              
              <div style="margin-top:10px" class="form-group">
                <div class="col-sm-12 controls">
                  <button type="submit" class="btn btn-success">Iniciar Sesi&oacute;n</a>
                </div>
              <div style="float:right; font-size:80%; position:relative; top:-10;">
                  ¿No estas registrado? <a href="registroU2.php">Registrate aqui.</a>
                </div>
              </div> 
            </form>
             <div style ="font-size:16px; color:#cc0000;">
              <?php echo isset($error) ? utf8_decode($error): '' ; ?>
             </div>
          </div>
        </div>
      </div>  
    </div>




    <!--jQuery 3.3.1 sin slim-->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <!--Bootstrap JS 4.2.1-->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous">
    </script>

</body>

</html>