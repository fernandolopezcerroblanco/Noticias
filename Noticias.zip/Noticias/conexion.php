<?php
	$mysqli=new mysqli("localhost","root","","noticias_db"); 		//Servidor, usuario de la base de datos,  contraseña del usuario,nombre de la base de datos

	//mysqli_query("SET NAMES 'utf8'");
	$acentos = $mysqli->query("SET NAMES 'utf8'");				//respeta los signos españoles

	if(mysqli_connect_errno())
	{
		echo 'Conexion Falida: ', mysqli_connect_error();
		exit();
	}
?>