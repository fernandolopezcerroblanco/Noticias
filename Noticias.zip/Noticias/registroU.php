<?php //al refrescar la pagina llena los datos en el formulario
   // header ('Content-type: text/html; charset=utf-8');
  session_start();
  require ("conexion.php");

  if(!isset($_SESSION["id_usuario"])){//Comprobara si ya hay una sesion iniciada
    header("Location:index.php"); //si no es asi nos redireccionara a la pagina principal
  }

  
  $idUsuario = $_SESSION['id_usuario'];

  if($_SESSION['Id_Priv']==1) {
        $sql = "SELECT Usuario_Log,`Usuario_N`, `Usuario_AP`, `Usuario_AM` FROM usuarios WHERE id_usuario='$idUsuario'";
    $result=$mysqli->query($sql);
    $row= $result->fetch_assoc();
  }
   
  $idUsuario = $_SESSION['id_usuario'];
  $bandera=false;
  $errors = array();  
  $activo='activo';
  $sql= "SELECT id_privilegio,tipo FROM privilegios";
  $resultp= $mysqli->query($sql); 

   $sql= "SELECT `Tipo_U`, `T_Clave` FROM `tipo_usuario`";
  $resultp123= $mysqli->query($sql);

   $sql= "SELECT `id_privilegio`, `tipo` FROM `privilegios`";
  $resultp12345= $mysqli->query($sql);


  
  if(!empty($_POST)){

    $nombre_u = $mysqli->real_escape_string($_POST['nombre_u']);
    $ApellidoP = $mysqli->real_escape_string($_POST['ApellidoP']);
    $ApellidoM = $mysqli->real_escape_string($_POST['ApellidoM']);
    $Direccion = $mysqli->real_escape_string($_POST['Direccion']);
    $login = $mysqli->real_escape_string($_POST['login']);
    $contrasenia = $mysqli->real_escape_string($_POST['contrasenia']);
    $contrasenia2 = $mysqli->real_escape_string($_POST['contrasenia2']);
    $id_priv =$mysqli->real_escape_string($_POST['tipot']);  
    $personal =$mysqli->real_escape_string($_POST['id_personal']);  

 


    $sha1 = sha1($contrasenia); 
    $error='';  
      $sql23455="SELECT `Id_Personal_L`, `Id_Usuario` FROM `usuarios` where Usuario_Log='$login'";
        $resultR3455=$mysqli->query($sql23455);
          $rows1= $resultR3455-> num_rows;

              if($rows1>0){
                print("Usuario Ya Existe");
                  }else{
    
      if($contrasenia == $contrasenia2){
        if($id_priv==null || $id_priv==0){
          $error="No selecciono el tipo de usuario";
        }else{
          $sql="SELECT `Id_personal`, `A_Paterno`, `A_Materno`, `Nombre`, `Direccion`, `Fecha_Ingreso` FROM `personal` WHERE `Id_personal`='$personal'";
          $result=$mysqli->query($sql);
          $rows= $result-> num_rows;
          if($rows > 0){
            $error="El ID personal ya existe!";
          }else{
          
              $sql23="INSERT INTO `usuarios`(`Id_Usuario`, `Usuario_Log`, `Contrasena`, `Fecha_Registro`,`Usuario_N`, `Usuario_AP`, `Usuario_AM`, `Id_Personal_L`, `Tipo_Usuario`, `Id_Priv`, `estado`) VALUES (null,'$login','$sha1',NOW(),'$nombre_u','$ApellidoP','$ApellidoM','$personal',1,'$id_priv','activo')";


            
              $resultR2=$mysqli->query($sql23);
              if($resultR2>0){


               
                $sql234="SELECT `Id_Personal_L`, `Id_Usuario` FROM `usuarios` where Id_Personal_L='$personal'";
              $resultR34=$mysqli->query($sql234);
             
                   while ($user=$resultR34->fetch_assoc()) {   
                   $Id_UsuarioU= $user['Id_Usuario']; 
                     }
              $rows= $resultR34-> num_rows;
              if($rows>0){


                 $sql2="INSERT INTO `personal`(`Id_personal`, `A_Paterno`, `A_Materno`, `Nombre`, `Direccion`, `Fecha_Ingreso`,Id_UsuarioP) VALUES ('$personal','$ApellidoP','$ApellidoM','$nombre_u','$Direccion',NOW(),'$Id_UsuarioU')";
              $resultR=$mysqli->query($sql2);
                if($resultR>0){
                $bandera=true;
                $nombre_u='';
                 $ApellidoP='';
                  $ApellidoM='';
                   $Direccion='';
                    $login='';
                     $contrasenia='';
                      $contrasenia2='';
                      $personal='';

               }else{
               $error="Error al registrar Usuario";
               }
              
              }else{
               $error="Error No se encuentra registro";
              }
            //else gender desicion     
          }
        }
        }
      }else{
     
        $error="Las contrasenias no coinciden, verificalas!";
        $contrasenia='';
        $contrasenia2='';
      }
       }
      //llave else id usuario null
  }///////POST  



?>
<script language="JavaScript">
function pregunta(){
    if (confirm('¿Estas seguro de enviar este formulario?')){
       document.tuformulario.submit()
    }
}
</script>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>RegistroU</title>
    <!--CSS de Bootstrap 4.2.1-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <!--Font Awesome-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
        integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <!--Google Fonts-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,500&display=swap" rel="stylesheet">
    <!-- owner -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body> 
  <header>

        <nav class="navbar navbar-expand-lg navbar-dark fixed-top color-fondo " style="  background-color:#2b130c;">

             <section class="container">

                <a class="navbar-brand" href="#">
                    <img  class="mb-2" src="imagenes/logo_c.png" width="200" height="70" class="img-fluid" alt="logo-black">

                </a>
       
                         
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                       <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto ">
         <?php if($_SESSION['Id_Priv']==1 || $_SESSION['Id_Priv']==2){ ?>
                              <li class="nav-item">
                                  <a class="nav-link"  href="#"><?php echo ' '; echo ''.($row['Usuario_N']).' '; echo ''.($row['Usuario_AP']).''; echo ' '.($row['Usuario_AM']).'';?> </a>   </li>


                <?php } ?>
              </ul></div>

             
              <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto ">
                     
                                    
                                <li class="nav-item">
                                  <a class="nav-link"  href="welcome.php">Inicio <span ></span></a>
                                 
                                    <?php if($_SESSION['Id_Priv']==1  && $_SESSION['Tipo_Usuario']==1  || $_SESSION['Id_Priv']==1  && $_SESSION['Tipo_Usuario']==2 ){ ?>
                                <li class="nav-item">
                                  <a class="nav-link"  href="registroU.php">Registro <span ></span></a>
                                  <?php } ?>

                                 <li class="nav-item">
                                  <a class="nav-link"  href="logout.php">Salir <span ></span></a>
                                 
                                </ul>

                </div>
            </section>
        </nav>
    </header>
 
   
        <div class="container" style="padding-top: 100px" >
      

           


          <div style="padding-top:30px" class="panel-body" align="center">
            <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
          
             <form id="signupform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST"  autocomplete="off">
                            
                            <div id="signupalert" style="display:none" class="alert alert-danger">
                                <p>Error:</p>
                                <span></span>
                            </div>
                            <table  width="100%">
                              <th>
                                  <div class="form-group">
                                <label for="nombre" class="col-md-3 control-label">Nombre:</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" name="nombre_u" placeholder="Nombre" value="<?php if(isset($nombre_u)) echo $nombre_u; ?>" required >
                                </div>
                            </div>
                             <div class="form-group">
                                <label for="ApellidoP" class="col-md-3 control-label">ApellidoP:</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" name="ApellidoP" placeholder="Apellido paterno" value="<?php if(isset($ApellidoP)) echo $ApellidoP; ?>" required >
                                </div>
                            </div>
                             <div class="form-group">
                                <label for="ApellidoM" class="col-md-3 control-label">ApellidoM:</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" name="ApellidoM" placeholder="apellido materno" value="<?php if(isset($ApellidoM)) echo $ApellidoM; ?>" required >
                                </div>
                            </div>
                              <div class="form-group">
                                <label for="ApellidoM" class="col-md-3 control-label">Direccion:</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" name="Direccion" placeholder="Direccion" value="<?php if(isset($ApellidoM)) echo $ApellidoM; ?>" required >
                                </div>
                            </div>
                              </th>
                              
                               <th>
                                  <div class="form-group">
                                <label for="nombre" class="col-md-3 control-label">Id Personal:</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" name="id_personal" placeholder="Id Personal" value="<?php if(isset($email)) echo $email; ?>" required >
                                </div>
                            </div>
                                 <div class="form-group">
                                <label for="nombre" class="col-md-3 control-label">Usuario Login:</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" name="login" placeholder="Nombre.apellido" value="<?php if(isset($email)) echo $email; ?>" required >
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="nombre" class="col-md-3 control-label">Contraseña:</label>
                                <div class="col-md-9">
                                    <input type="password" class="form-control" name="contrasenia" placeholder="Contraseña" value="<?php if(isset($contrasenia)) echo $contrasenia; ?>" required >
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="nombre" class="col-md-3 control-label">Confirma tu contraseña:</label>
                                <div class="col-md-9">
                                    <input type="password" class="form-control" name="contrasenia2" placeholder="Confirmar contraseña" value="<?php if(isset($contrasenia2)) echo $contrasenia2; ?>" required >
                                </div>
                            </div>
                   
                              <div class="form-group">
                                <label class="col-md-3 control-label">Tipo Usuario:</label>
                                <div class="col-md-9">
                                    <select id="puesto" name="tipot" class="form-control">
                                        <option value="0" >Seleccione el tipo</option>
                                        <?php while($row=$resultp12345->fetch_assoc()) {?>
                                            <option value="<?php echo $row['id_privilegio'];?>" required><?php echo $row['tipo'];?> </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                                
                              </th>

                            </table>
                          
                             
                            
                          
                            
                            <div class="form-group">                                      
                                <div class="col-md-offset-3 col-md-9">
                                    <button id="btn-signup" type="submit" onclick="pregunta()"  class="btn btn-info"><i class="icon-hand-right"></i>Registrar</button> 
                                </div>
                            </div>
                        </form>
                        <?php if($bandera){ ?>
                            <div class="form-group">
                                <label for="con_password" class="col-md-3 control-label">¡Registro Exitoso!</label>
                            </div>  
                        <?php } else {  ?>
                            <div style="font-size:16px; color:#50565b"> <?php echo isset($error) ?utf8_decode($error):'';?> </div>
                        <?php }?>
          </div>
        </div>
      </div>  
    </div>
                                     


    <!--jQuery 3.3.1 sin slim-->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <!--Bootstrap JS 4.2.1-->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous">
    </script>

</body>

</html>