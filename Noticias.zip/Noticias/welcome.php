<?php

  session_start();
  require ("conexion.php");
  //validar que la sesion existe, si no regresar a index nombre 
  if(!isset($_SESSION["Usuario_Log"])){      //Comprobara si ya hay una sesion iniciada
    header("Location: index.php");              //si no es asi nos redireccionara a la pagina principal
  }
  $idUsuario = $_SESSION['id_usuario'];
    
  if($_SESSION['Id_Priv']==1  || $_SESSION['Id_Priv']==2  ) {
        $sql1 = "SELECT Usuario_Log,`Usuario_N`, `Usuario_AP`, `Usuario_AM` FROM usuarios WHERE id_usuario='$idUsuario'";
    $result=$mysqli->query($sql1);
    $row= $result->fetch_assoc();
  }
 
  if(!empty($_POST)){
    $Comentario = $mysqli->real_escape_string($_POST['Comentario']);
     $Id_Noticia = $mysqli->real_escape_string($_POST['noticia']);
    $error='';  



          $sql = "SELECT u.Usuario_Log,u.Id_Personal_L FROM usuarios u inner join personal p on (p.Id_personal=u.Id_Personal_L) WHERE Tipo_Usuario in (1,2) and id_usuario='$idUsuario'";
    $result234=$mysqli->query($sql);
        while($row1=$result234->fetch_assoc()) {
          $Id_personal =$row1['Id_Personal_L'];
           }
           $rows= $result234-> num_rows;

  if($rows>0){


            $sql343="INSERT INTO `comentarios`(`Id_Cometarios`, `Id_Noticias`, `Comentario`, `Id_Usuario_C`, `Fecha_C`) VALUES (null,'$Id_Noticia','$Comentario','$idUsuario',NOW());";
              $resultR343=$mysqli->query($sql343);
              if($resultR343>0){
               $bandera=true;
               $Comentario ='' ;
               header("Refresh:0");
              
               }else{
                print("Error al insertar");
                
               }

 }else{

      $sql22 = "SELECT `Id_Usuario`, `Usuario_Log`, `Contrasena`, `Fecha_Registro`, `Id_Personal_L`, `Usuario_N`, `Usuario_AP`, `Usuario_AM`, `Tipo_Usuario`, `Id_Priv`, `estado` FROM `usuarios` WHERE `Id_Usuario`='$idUsuario'";
    $result2342=$mysqli->query($sql22);
        $rows= $result2342-> num_rows;

  if($rows>0){

              $sql34="INSERT INTO `comentarios`(`Id_Cometarios`, `Id_Noticias`, `Comentario`, `Id_Usuario_C`, `Fecha_C`) VALUES (null,'$Id_Noticia','$Comentario','$idUsuario',NOW());";
              $resultR34=$mysqli->query($sql34);
              if($resultR34>0){
               $bandera=true;
               $Comentario ='' ;
              header("Refresh:0");
               }else{
                print("Error al insertar");
                
               }



}else{

print("Usuario No Existe");
}


 }

                
               
  }
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Inicio</title>
    <!--CSS de Bootstrap 4.2.1-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <!--Font Awesome-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
        integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <!--Google Fonts-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,500&display=swap" rel="stylesheet">
    <!-- owner -->
 


</head>

<body>
  
 <header>

        <nav class="navbar navbar-expand-lg navbar-dark fixed-top color-fondo " style="  background-color:#2b130c;">

             <section class="container">

                <a class="navbar-brand" href="#">
                    <img  class="mb-2" src="imagenes/logo_c.png" width="200" height="70" class="img-fluid" alt="logo-black">

                </a>
       
                         
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                       <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto ">
         <?php if($_SESSION['Id_Priv']==1 || $_SESSION['Id_Priv']==2){ ?>
                              <li class="nav-item">
                                  <a class="nav-link"  href="#"><?php echo ' '; echo ''.($row['Usuario_N']).' '; echo ''.($row['Usuario_AP']).''; echo ' '.($row['Usuario_AM']).'';?> </a>   </li>


                <?php } ?>
              </ul></div>

             
              <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto ">
                     
                                    
                                <li class="nav-item">
                                  <a class="nav-link"  href="welcome.php">Inicio <span ></span></a>
                                 
                                    <?php if($_SESSION['Id_Priv']==1  && $_SESSION['Tipo_Usuario']==1  || $_SESSION['Id_Priv']==1  && $_SESSION['Tipo_Usuario']==2 ){ ?>
                                <li class="nav-item">
                                  <a class="nav-link"  href="registroU.php">Registro <span ></span></a>
                                  <?php } ?>

                                 <li class="nav-item">
                                  <a class="nav-link"  href="logout.php">Salir <span ></span></a>
                                 
                                </ul>

                </div>
            </section>
        </nav>
    </header>
  
   
      <div style="padding: 170px" >

        <table border="0" width="100%">
                                  <th width="30%">

                                <div class="col-md-offset-3 col-md-9">
                                  <?php if($_SESSION['Id_Priv']==1  && $_SESSION['Tipo_Usuario']==1  || $_SESSION['Id_Priv']==1  && $_SESSION['Tipo_Usuario']==2 ){ ?>

                                  <a  href="CrearNoticia.php">
                                    <button id="btn-signup" type="submit"   class="btn btn-info"><i class="icon-hand-right"></i> Crear nueva noticia</button> </a>
                                    <?php } ?>
                                </div>
                                  </th>

                                  <th width="70%">
                                 
<?php
  $sqls= 'SELECT n.Id_noticias, n.N_Titulo, n.N_Descripcion, n.Fecha_N, n.Id_Personal_N,p.Nombre, p.A_Paterno, p.A_Materno FROM noticias n inner join personal p on (p.Id_personal =n.Id_Personal_N)';
  $consulta_h=$mysqli->query($sqls);
?>

      <?php 
        while ($user=$consulta_h->fetch_assoc()) {  
          $Id_Noticia=$user['Id_noticias'];  ?>
       
          <div class="">

            <div class="blockquote"> 

              <div class="blockquote" data-aos="" style="background-color: ;"> 
         
                <h4 class="title"><a href="Comentarios.php?&Comentarios=<?php echo $user['Id_noticias'];?>"><?php echo $user['N_Titulo']; ?></a></h4>
                <div align="left"><small><?php print("Fecha:"); echo $user['Fecha_N']; print(" Usuario:"); echo $user['Nombre'].' '; echo $user['A_Paterno'].' ';echo $user['A_Materno'].' ';?></small> </div>  
                <p class=""><?php echo $user['N_Descripcion']; ?></p>

                 <div align="left"><small>Comentarios</small> </div> 
                 <?php
  $sqls4= "SELECT c.Id_Cometarios, c.Id_Noticias, c.Comentario, c.Id_Usuario_C, c.Fecha_C,u.Usuario_N, `Usuario_AP`, `Usuario_AM` FROM comentarios c INNER JOIN noticias n on (n.Id_noticias=c.Id_Noticias) INNER JOIN usuarios u on (u.Id_Usuario=c.Id_Usuario_C) where c.Id_Noticias ='$Id_Noticia' ORDER by c.Id_Cometarios DESC LIMIT 1";
  $consulta_h4=$mysqli->query($sqls4);
?>

      <?php 
        while ($user3=$consulta_h4->fetch_assoc()) {   
          ?>
          <div style=" background-color:  ;">
          <div align="left"><small>Fecha:<?php echo $user3['Fecha_C']; print("  Usuario: "); echo $user3['Usuario_N'].' ';  echo $user3['Usuario_AP'].' '; echo $user3['Usuario_AM'].' ';   ?> </small> </div> 
          <div align="left"><small><?php echo $user3['Comentario']; ?> </small> </div>
           </div>
           <?php  
   
                }
                ?>

                   
             <form id="signupform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" autocomplete="off">
              <input type="hidden" name="noticia" value="<?php echo $user['Id_noticias'];?>">
                            
                        <table width="100%">
                          <th>
                             <div class="form-group">
                                <label for="ApellidoP" class="col-md-3 control-label">Comentario:</label>
                                <div class="col-md-9">
                                    <textarea class="form-control"  name="Comentario" value="" required></textarea>
                            </div>
                          </th>
                          <th>
                            
                            <div class="form-group" align="center" style="padding-top: 50px">                                      
                                <div class="col-md-offset-3 col-md-9">
                                    <button id="btn-signup" type="submit"  class="btn btn-info"><i class="icon-hand-right"></i>Registrar</button> 
                                </div>
                            </div>
                            </th>
                            </table>
                        </form>
              </div>
              
             
          </div>
        </div>

       <?php } ?>
     
               

<style type="text/css">
   .wrapper { background-color:  blue;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    grid-template-rows: 100px 100px;
    grid-gap: 10px;
}
blockquote {
  padding: 3px 10px;
  border: PowderBlue 5px solid;
  border-radius: 20px;
}
</style>
 



    <!--jQuery 3.3.1 sin slim-->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <!--Bootstrap JS 4.2.1-->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous">
    </script>

</body>

</html>