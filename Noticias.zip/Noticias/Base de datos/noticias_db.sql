-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 25-01-2022 a las 07:57:17
-- Versión del servidor: 10.1.35-MariaDB
-- Versión de PHP: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `noticias_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `Id_Cometarios` int(30) NOT NULL,
  `Id_Noticias` int(30) NOT NULL,
  `Comentario` varchar(200) NOT NULL,
  `Id_Usuario_C` int(30) NOT NULL,
  `Fecha_C` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`Id_Cometarios`, `Id_Noticias`, `Comentario`, `Id_Usuario_C`, `Fecha_C`) VALUES
(5, 3, 'Estoy Orgullo de la empresa.', 15, '2022-01-24'),
(8, 4, 'Un placer pertenecer a esta corporacion', 2, '2022-01-24'),
(9, 3, 'El Servicio de la compañía es fundamental para nuestros clientes.', 2, '2022-01-24'),
(14, 3, 'Los Clientes se encuentras satisfechos con nuestro trabajo', 2, '2022-01-24'),
(15, 4, 'Un gusto estar en esta empresa', 16, '2022-01-24'),
(16, 4, 'Me gustaría Pertenecer a la empresa', 14, '2022-01-24');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticias`
--

CREATE TABLE `noticias` (
  `Id_noticias` int(30) NOT NULL,
  `N_Titulo` varchar(70) NOT NULL,
  `N_Descripcion` varchar(200) NOT NULL,
  `Fecha_N` date NOT NULL,
  `Id_Personal_N` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `noticias`
--

INSERT INTO `noticias` (`Id_noticias`, `N_Titulo`, `N_Descripcion`, `Fecha_N`, `Id_Personal_N`) VALUES
(3, 'Grupo Castores', 'Transportes Castores tiene el firme propósito de lograr la satisfacción de sus clientes, proporcionándoles productos y servicios especializados de transporte.', '2022-01-24', 58698),
(4, 'Aniversario!!!!', ' En 1974, Refugio Muñoz Herrera fundó Transportes Castores en Baja California, una empresa conformada por un grupo de socios', '2022-01-24', 58698);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal`
--

CREATE TABLE `personal` (
  `Id_personal` int(30) NOT NULL,
  `A_Paterno` varchar(50) NOT NULL,
  `A_Materno` varchar(50) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Direccion` varchar(100) NOT NULL,
  `Fecha_Ingreso` date NOT NULL,
  `Id_UsuarioP` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `personal`
--

INSERT INTO `personal` (`Id_personal`, `A_Paterno`, `A_Materno`, `Nombre`, `Direccion`, `Fecha_Ingreso`, `Id_UsuarioP`) VALUES
(5846, 'Lopez', 'Llanos', 'Raul', 'Santa Cruz de Juventino Rosas', '2022-01-24', 15),
(23122, '.', '.', 'Admin', '.', '2022-01-23', 3),
(23123, 'Lopez', 'c', 'Fernando', 'Santa Cruz de Juventino Rosas', '2022-01-23', 4),
(58698, 'Lopez', 'LLanos', 'Pedro', 'Santa Cruz de Juventino Rosas', '2022-01-24', 16);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personalexterno`
--

CREATE TABLE `personalexterno` (
  `Id_UsuarioE` int(30) NOT NULL,
  `UsuarioNE` varchar(50) NOT NULL,
  `A_PaternoE` varchar(50) NOT NULL,
  `A_MaternoE` varchar(50) NOT NULL,
  `Id_Usuario_R` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `personalexterno`
--

INSERT INTO `personalexterno` (`Id_UsuarioE`, `UsuarioNE`, `A_PaternoE`, `A_MaternoE`, `Id_Usuario_R`) VALUES
(3, 'Fernando', '', '', 14);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `privilegios`
--

CREATE TABLE `privilegios` (
  `id_privilegio` int(11) NOT NULL,
  `tipo` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `privilegios`
--

INSERT INTO `privilegios` (`id_privilegio`, `tipo`) VALUES
(1, 'Administrador'),
(2, 'General');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas`
--

CREATE TABLE `respuestas` (
  `Id_Respuesta` int(30) NOT NULL,
  `Id_Comentario` int(30) NOT NULL,
  `Respuesta` varchar(200) NOT NULL,
  `Fecha_R` date NOT NULL,
  `Id_Usuario_R` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `respuestas`
--

INSERT INTO `respuestas` (`Id_Respuesta`, `Id_Comentario`, `Respuesta`, `Fecha_R`, `Id_Usuario_R`) VALUES
(7, 9, 'Tienes Razón los clientes se encuentran satisfechos con nuestro trabajo. ', '2022-01-24', 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_usuario`
--

CREATE TABLE `tipo_usuario` (
  `Tipo_U` int(2) NOT NULL,
  `T_Clave` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipo_usuario`
--

INSERT INTO `tipo_usuario` (`Tipo_U`, `T_Clave`) VALUES
(1, 'Interno'),
(2, 'Externo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `Id_Usuario` int(30) NOT NULL,
  `Usuario_Log` varchar(30) NOT NULL,
  `Contrasena` varchar(80) NOT NULL,
  `Fecha_Registro` date NOT NULL,
  `Usuario_N` varchar(50) NOT NULL,
  `Usuario_AP` varchar(50) NOT NULL,
  `Usuario_AM` varchar(50) NOT NULL,
  `Id_Personal_L` int(30) NOT NULL,
  `Tipo_Usuario` int(2) NOT NULL,
  `Id_Priv` int(2) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`Id_Usuario`, `Usuario_Log`, `Contrasena`, `Fecha_Registro`, `Usuario_N`, `Usuario_AP`, `Usuario_AM`, `Id_Personal_L`, `Tipo_Usuario`, `Id_Priv`, `estado`) VALUES
(2, 'admin', 'f0e70f290137bf829d8c33cfa7e1e7221cb320e6', '0000-00-00', 'admin', '.', '.', 23122, 1, 1, 'activo'),
(3, 'Fernando.Lopez', 'd033e22ae348aeb5660fc2140aec35850c4da997', '2022-01-23', 'Fernando', 'Lopez', 'C', 23123, 1, 1, 'activo'),
(14, 'Fernando.L', '7a67c21da6dd5f977da2d4828e49cb7083d8d1d6', '2022-01-24', 'Fernando', 'Lopez', 'C', 0, 2, 2, 'activo'),
(15, 'Raul.L', '4e830a78ca3b2d06259ff6510bbb63ca64f3e0e2', '2022-01-24', 'Raul', 'Lopez', 'LLanos', 5846, 1, 2, 'activo'),
(16, 'Pedro', '89b896402d8c3d208029b5b46597910af7e34a66', '2022-01-24', 'Pedro', 'Lopez', 'LLanos', 58698, 1, 1, 'activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`Id_Cometarios`),
  ADD KEY `Id_Usuario_C` (`Id_Usuario_C`),
  ADD KEY `Id_Noticias` (`Id_Noticias`);

--
-- Indices de la tabla `noticias`
--
ALTER TABLE `noticias`
  ADD PRIMARY KEY (`Id_noticias`),
  ADD KEY `Id_Personal_N` (`Id_Personal_N`);

--
-- Indices de la tabla `personal`
--
ALTER TABLE `personal`
  ADD PRIMARY KEY (`Id_personal`),
  ADD KEY `Id_UsuarioP` (`Id_UsuarioP`);

--
-- Indices de la tabla `personalexterno`
--
ALTER TABLE `personalexterno`
  ADD PRIMARY KEY (`Id_UsuarioE`),
  ADD KEY `Id_Usuario_R` (`Id_Usuario_R`);

--
-- Indices de la tabla `privilegios`
--
ALTER TABLE `privilegios`
  ADD PRIMARY KEY (`id_privilegio`);

--
-- Indices de la tabla `respuestas`
--
ALTER TABLE `respuestas`
  ADD PRIMARY KEY (`Id_Respuesta`),
  ADD KEY `Id_Comentario` (`Id_Comentario`),
  ADD KEY `Id_Usuario_R` (`Id_Usuario_R`);

--
-- Indices de la tabla `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  ADD PRIMARY KEY (`Tipo_U`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`Id_Usuario`),
  ADD KEY `Tipo_Usuario` (`Tipo_Usuario`),
  ADD KEY `Id_Priv` (`Id_Priv`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `Id_Cometarios` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `noticias`
--
ALTER TABLE `noticias`
  MODIFY `Id_noticias` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `personalexterno`
--
ALTER TABLE `personalexterno`
  MODIFY `Id_UsuarioE` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `privilegios`
--
ALTER TABLE `privilegios`
  MODIFY `id_privilegio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `respuestas`
--
ALTER TABLE `respuestas`
  MODIFY `Id_Respuesta` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  MODIFY `Tipo_U` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `Id_Usuario` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD CONSTRAINT `comentarios_ibfk_1` FOREIGN KEY (`Id_Noticias`) REFERENCES `noticias` (`Id_noticias`);

--
-- Filtros para la tabla `noticias`
--
ALTER TABLE `noticias`
  ADD CONSTRAINT `noticias_ibfk_1` FOREIGN KEY (`Id_Personal_N`) REFERENCES `personal` (`Id_personal`);

--
-- Filtros para la tabla `personal`
--
ALTER TABLE `personal`
  ADD CONSTRAINT `personal_ibfk_1` FOREIGN KEY (`Id_UsuarioP`) REFERENCES `usuarios` (`Id_Usuario`);

--
-- Filtros para la tabla `personalexterno`
--
ALTER TABLE `personalexterno`
  ADD CONSTRAINT `personalexterno_ibfk_1` FOREIGN KEY (`Id_Usuario_R`) REFERENCES `usuarios` (`Id_Usuario`);

--
-- Filtros para la tabla `respuestas`
--
ALTER TABLE `respuestas`
  ADD CONSTRAINT `respuestas_ibfk_1` FOREIGN KEY (`Id_Comentario`) REFERENCES `comentarios` (`Id_Cometarios`),
  ADD CONSTRAINT `respuestas_ibfk_2` FOREIGN KEY (`Id_Usuario_R`) REFERENCES `usuarios` (`Id_Usuario`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_2` FOREIGN KEY (`Tipo_Usuario`) REFERENCES `tipo_usuario` (`Tipo_U`),
  ADD CONSTRAINT `usuarios_ibfk_3` FOREIGN KEY (`Id_Priv`) REFERENCES `privilegios` (`id_privilegio`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
