<?php

  session_start();
  unset ($SESSION['username']);
  session_destroy();

//header('Location: http://localhost/dashboard/menu/index.php');  //entorno local
header('Location: index.php');    //desde el servidor
?>