<?php //al refrescar la pagina llena los datos en el formulario
   // header ('Content-type: text/html; charset=utf-8');
  session_start();
  require ("conexion.php");
  
    if(!isset($_SESSION["id_usuario"])){//Comprobara si ya hay una sesion iniciada
    header("Location:index.php"); //si no es asi nos redireccionara a la pagina principal
  }


  
  $idUsuario = $_SESSION['id_usuario'];

  if($_SESSION['Id_Priv']==1) {
        $sql = "SELECT Usuario_Log,`Usuario_N`, `Usuario_AP`, `Usuario_AM` FROM usuarios WHERE id_usuario='$idUsuario'";
    $result=$mysqli->query($sql);
    $row= $result->fetch_assoc();
  }

  $bandera=false;
  $bandera1=false;
  $errors = array();  
  $activo='activo';


  
  if(!empty($_POST)){
    $Titulo = $mysqli->real_escape_string($_POST['titulo']);
    $Descripcion = $mysqli->real_escape_string($_POST['Descripcion']);
    $error='';  



          $sql = "SELECT u.Usuario_Log,u.Id_Personal_L FROM usuarios u inner join personal p on (p.Id_personal=u.Id_Personal_L) WHERE Tipo_Usuario=1 and id_usuario='$idUsuario'";
    $result234=$mysqli->query($sql);
        while($row=$result234->fetch_assoc()) {
          $Id_personal =$row['Id_Personal_L'];
           }
           $rows= $result234-> num_rows;

  if($rows>0){


              $sql3="INSERT INTO `noticias`(`Id_noticias`, `N_Titulo`, `N_Descripcion`, `Fecha_N`, `Id_Personal_N`) VALUES (null,'$Titulo','$Descripcion',NOW(),'$Id_personal');";
              $resultR3=$mysqli->query($sql3);
              if($resultR3>0){
               $bandera=true;
               $Descripcion ='' ;
               $Titulo ='' ;
        

                
               }else{
                print("Error al insertar");
                
               }

 }else{
$bandera1=true;
print("error en consulta");
 }

                
               
  }


?>
<script language="JavaScript">
function pregunta(){
    if (confirm('¿Estas seguro de enviar este formulario?')){
       document.tuformulario.submit()
    }
}
</script>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Noticia</title>
    <!--CSS de Bootstrap 4.2.1-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <!--Font Awesome-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
        integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <!--Google Fonts-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,500&display=swap" rel="stylesheet">
    <!-- owner -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body> 
   <header>

        <nav class="navbar navbar-expand-lg navbar-dark fixed-top color-fondo " style="  background-color:#2b130c;">

             <section class="container">

                <a class="navbar-brand" href="#">
                    <img  class="mb-2" src="imagenes/logo_c.png" width="200" height="70" class="img-fluid" alt="logo-black">

                </a>
       
                         
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                       <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto ">
         <?php if($_SESSION['Id_Priv']==1 || $_SESSION['Id_Priv']==2){ ?>
                              <li class="nav-item">
                                  <a class="nav-link"  href="#"><?php echo ' '; echo ''.($row['Usuario_N']).' '; echo ''.($row['Usuario_AP']).''; echo ' '.($row['Usuario_AM']).'';?> </a>   </li>


                <?php } ?>
              </ul></div>

             
              <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto ">
                     
                                    
                                <li class="nav-item">
                                  <a class="nav-link"  href="welcome.php">Inicio <span ></span></a>
                                 
                                    <?php if($_SESSION['Id_Priv']==1  && $_SESSION['Tipo_Usuario']==1  || $_SESSION['Id_Priv']==1  && $_SESSION['Tipo_Usuario']==2 ){ ?>
                                <li class="nav-item">
                                  <a class="nav-link"  href="registroU.php">Registro <span ></span></a>
                                  <?php } ?>

                                 <li class="nav-item">
                                  <a class="nav-link"  href="logout.php">Salir <span ></span></a>
                                 
                                </ul>

                </div>
            </section>
        </nav>
    </header>
 
   
        <div class="container" align="center" style="padding-top: 130px">
      

           


          <div style="padding-top:30px" class="panel-body" >
            <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
          
             <form id="signupform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" autocomplete="off">
                            
                            <div id="signupalert" style="display:none" class="alert alert-danger">
                                <p>Error:</p>
                                <span></span>
                            </div>
                        
                            <table width="100%"> <th width="30%">
                            <div class="form-group">
                                <label for="nombre" class="col-md-3 control-label">Titulo:</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" name="titulo" placeholder="Titulo" value="" required >
                                </div>
                            </div>
                            </th>
                            <th width="70%">
                             <div class="form-group">
                                <label for="ApellidoP" class="col-md-3 control-label">Descripcion:</label>
                                <div class="col-md-9">
                                    <textarea class="form-control"  name="Descripcion" value="" required></textarea>
                            </div>
                            </th>
                            <th width="10%">
                            <div class="form-group" align="center" style="padding-top: 50px">                                      
                                <div class="col-md-offset-3 col-md-9">
                                    <button id="btn-signup" type="submit"  onclick="pregunta()" class="btn btn-info"><i class="icon-hand-right"></i>Registrar</button> 
                                </div>
                            </div>
                            </th>
                            </table>
                        </form>
                        <?php if($bandera){ ?>
                            <div class="form-group">
                                <label for="con_password" class="col-md-3 control-label" style="color: green;" >¡Registro Exitoso!</label>
                            </div>  
                        <?php } else {  ?>
                            <div style="font-size:16px; color:#50565b"> <?php echo isset($error) ?utf8_decode($error):'';?> </div>
                        <?php }?>
                           <?php if($bandera1){
                            print("Este Usuario no puede crear Noticias, porque no es un cliente Interno"); ?>
                            
                        <?php } else {  ?>
                           
                        <?php }?>
                       

          </div>
        </div>
      </div>  
    </div>
                                     


    <!--jQuery 3.3.1 sin slim-->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <!--Bootstrap JS 4.2.1-->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous">
    </script>

</body>

</html>